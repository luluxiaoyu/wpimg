Simple URLs
===========

Plugin that allows you to create custom redirects for pages and posts via a custom field.

