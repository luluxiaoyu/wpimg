<?php
/**
 * Plugin Name: Simple URLs（由电脑技术知识https://dnjszs.cn汉化）
 * Plugin URI: https://wordpress.org/plugins/simple-urls/
 * Description: 短链接是一个完整的URL管理系统，允许您使用自定义的post类型和301重定向创建、管理和跟踪来自站点的出站链接。
 * Author: Nathan Rice
 * Author URI: http://www.nathanrice.net/
 * Version: 0.9.9

 * Text Domain: simple-urls
 * Domain Path: /languages

 * License: GNU General Public License v2.0 (or later)
 * License URI: http://www.opensource.org/licenses/gpl-license.php
 *
 * @package simple-urls
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SIMPLE_URLS_DIR', plugin_dir_path( __FILE__ ) );
define( 'SIMPLE_URLS_URL', plugins_url( '', __FILE__ ) );

require_once SIMPLE_URLS_DIR . '/includes/class-simple-urls.php';

new Simple_Urls();

if ( is_admin() ) {
	require_once SIMPLE_URLS_DIR . '/includes/class-simple-urls-admin.php';
	new Simple_Urls_Admin();
}
function myplugin_init() {
  load_plugin_textdomain( 'simple-urls', false , dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
}
add_action('plugins_loaded', 'myplugin_init');
	
