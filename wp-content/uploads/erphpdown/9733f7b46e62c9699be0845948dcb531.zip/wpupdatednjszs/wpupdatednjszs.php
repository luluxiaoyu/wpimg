<?php
/*
Plugin Name: 电脑技术知识WordPress更新源
Plugin URI: https://dnjszs.cn
Description: 最近wordpress网站无法访问，国内运行的wp都无法更新，可以用这款插件更改更新源！（更新可能没有官方及时，7天检查一次）
Author: 小宇
Version: 1.0
Author URI: https://dnjszs.cn
*/ 

add_filter('site_transient_update_core', function($value){
	foreach ($value->updates as &$update) {
		if($update->locale == 'zh_CN'){
			$update->download	= 'https://dnjszs.cn/file/WordPress/update/wordpress-zh_CN.zip';
			$update->packages->full	= 'https://dnjszs.cn/file/WordPress/update/wordpress-zh_CN.zip';
		}
	}

	return $value;
});
?>