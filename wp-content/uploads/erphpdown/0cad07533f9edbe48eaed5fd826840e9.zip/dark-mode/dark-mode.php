<?php
/**
 * Plugin Name: Dark Mode
 * Plugin URI: https://wordpress.org/plugins/dark-mode/
 * Description: 让您的用户使WordPress管理仪表板拥有黑暗模式！（由<a href="https://dnjszs.cn">电脑技术知识</a>汉化）
 * Author: David Gwyer
 * Author URI: https://www.wpgoplugins.com/
 * Text Domain: dark-mode
 * Version: 3.2.1
 */

if ( ! defined( 'ABSPATH' ) ) {
	die();
}

require 'class-dark-mode.php';

$dark_mode = new Dark_Mode();

function myplugin_init() {
  load_plugin_textdomain( 'dark-mode', false , dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
}
add_action('plugins_loaded', 'myplugin_init');
